package org.hcl.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		String ename = request.getParameter("ename");
		String hname = request.getParameter("hname");
		String type = request.getParameter("type");
		String details = request.getParameter("details");
		String owner = request.getParameter("owner");
		String sdate = request.getParameter("sdate");
		String edate = request.getParameter("edate");
		out.println("<body>");
		out.println("<center><h1 style='color:green'>Event Sucessfully Registered!!!!</h1>");
		out.println("<div style='display:flex;justify-content:center;align-items:center;'>");
		out.println("<table style='border: 1px solid black' >");
		out.println("<tr><td style='border: 1px solid black'>Event Name</td><td style='border: 1px solid black'>"+ename+" </td></tr>");
		out.println("<tr><td style='border: 1px solid black'>Hall Name</td><td style='border: 1px solid black'>"+hname+"</td></tr>");
		out.println("<tr><td style='border: 1px solid black'>type</td><td style='border: 1px solid black'>"+type+" </td></tr>");
		out.println("<tr><td style='border: 1px solid black'>details</td><td style='border: 1px solid black'>"+details+" </td></tr>");
		out.println("<tr><td style='border: 1px solid black'>Owner Name</td><td style='border: 1px solid black'>"+owner+" </td></tr>");
		out.println("<tr><td style='border: 1px solid black'>Start Date</td><td style='border: 1px solid black'> "+sdate+"</td></tr>");
		out.println("<tr><td style='border: 1px solid black'>End Date</td><td style='border: 1px solid black'>"+edate+"</td></tr>");
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
	
	}

}
