package com.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/exhibition")
public class Exhibition extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		out.println("<body>");
		out.println("<center><h1 style='color:green'>Text Fair 2018 Expo</h1>");
		out.println("<div style='display:flex;justify-content:center;align-items:center;'>");
		out.println("<table style='border: 1px solid black' >");
		out.println("<tr><td style='border: 1px solid black'>Name</td><td style='border: 1px solid black'>Text Fair 2018 Expo</td></tr>");
		out.println("<tr><td style='border: 1px solid black'>Hall Name</td><td style='border: 1px solid black'>PVR SUPERPLEX</td></tr>");
		out.println("<tr><td style='border: 1px solid black'>Start Date</td><td style='border: 1px solid black'> 20-10-2018</td></tr>");
		out.println("<tr><td style='border: 1px solid black'>End Date</td><td style='border: 1px solid black'>30-10-2018</td></tr>");
		out.println("</table>");
		out.println("</div>");
		out.println("</body>");
		
		
		
	
	}

}
